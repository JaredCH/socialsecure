import React, { act } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';
import { authAPI, notificationAPI } from './utils/api';

jest.mock('./pages/Home', () => () => <div>Home Page</div>);
jest.mock('./pages/Login', () => () => <div>Login Page</div>);
jest.mock('./pages/Register', () => () => <div>Register Page</div>);
jest.mock('./pages/UserSettings', () => () => <div>User Settings Page</div>);
jest.mock('./pages/ReferFriend', () => () => <div>Refer Friend Page</div>);
jest.mock('./pages/Social', () => () => <div>Social Page</div>);
jest.mock('./pages/Chat', () => () => <div>Chat Page</div>);
jest.mock('./pages/Market', () => () => <div>Market Page</div>);
jest.mock('./pages/News', () => () => <div>News Page</div>);
jest.mock('./pages/Maps', () => () => <div>Maps Page</div>);
jest.mock('./pages/Discovery', () => () => <div>Discovery Page</div>);
jest.mock('./pages/Calendar', () => () => <div>Calendar Page</div>);
jest.mock('./pages/ResumeBuilder', () => () => <div>Resume Builder Page</div>);
jest.mock('./pages/OnboardingPage', () => () => <div>Onboarding Page</div>);
jest.mock('./pages/PostRegistrationWelcome', () => () => <div>Welcome Page</div>);
jest.mock('./pages/ModerationDashboard', () => () => <div>Moderation Dashboard</div>);
jest.mock('./components/NotificationCenter', () => () => <div>🔔</div>);
jest.mock('./pages/NotificationSettings', () => () => <div>Notification Settings</div>);
jest.mock('./pages/ResumePublic', () => () => <div>Public Resume</div>);
jest.mock('react-hot-toast', () => ({ Toaster: () => null }));

jest.mock('./utils/realtime', () => ({
  initRealtime: jest.fn(() => ({ on: jest.fn() })),
  disconnectRealtime: jest.fn()
}));

jest.mock('./utils/api', () => ({
  authAPI: {
    getProfile: jest.fn(),
    getEncryptionPasswordStatus: jest.fn(),
    getOnboardingStatus: jest.fn()
  },
  notificationAPI: {
    getUnreadCount: jest.fn(),
    getPreferences: jest.fn()
  }
}));

describe('App navbar features dropdown', () => {
  let container;
  let root;

  const renderApp = async () => {
    await act(async () => {
      root.render(<App />);
    });
    await act(async () => {
      await Promise.resolve();
    });
  };

  beforeEach(() => {
    localStorage.clear();
    sessionStorage.clear();
    jest.clearAllMocks();
    container = document.createElement('div');
    document.body.appendChild(container);
    root = createRoot(container);
    authAPI.getProfile.mockResolvedValue({
      data: {
        user: {
          _id: 'user-1',
          username: 'user1',
          hasEncryptionPassword: true,
          onboardingStatus: 'completed',
          onboardingStep: 4,
          unreadNotificationCount: 0
        }
      }
    });
    authAPI.getEncryptionPasswordStatus.mockResolvedValue({
      data: { hasEncryptionPassword: true, encryptionPasswordSetAt: null, encryptionPasswordVersion: 0 }
    });
    authAPI.getOnboardingStatus.mockResolvedValue({
      data: { status: 'completed', currentStep: 4, completedSteps: [1, 2, 3, 4] }
    });
    notificationAPI.getUnreadCount.mockResolvedValue({ data: { count: 0 } });
    notificationAPI.getPreferences.mockResolvedValue({ data: { preferences: { realtime: { enabled: false } } } });
  });

  afterEach(() => {
    act(() => {
      root.unmount();
    });
    container.remove();
    container = null;
    root = null;
    localStorage.clear();
    sessionStorage.clear();
    jest.clearAllMocks();
  });

  it('groups discover, calendar, and resume under Features for authenticated users', async () => {
    localStorage.setItem('token', 'token');

    await renderApp();

    expect(authAPI.getProfile).toHaveBeenCalled();

    const featuresMenu = container.querySelector('[data-testid="features-menu"]');
    expect(featuresMenu).not.toBeNull();
    const featuresButton = featuresMenu.querySelector('button');
    expect(featuresButton).not.toBeNull();

    await act(async () => {
      featuresButton.click();
    });

    const dropdownPanel = container.querySelector('#features-menu-panel');
    expect(dropdownPanel).not.toBeNull();
    expect(dropdownPanel.className).toContain('top-full');
    expect(dropdownPanel.className).toContain('z-[1310]');
    expect(featuresMenu.parentElement.className).toContain('overflow-visible');

    expect(featuresMenu.textContent).toContain('Features');
    expect(featuresMenu.textContent).toContain('Discover');
    expect(featuresMenu.textContent).toContain('Calendar');
    expect(featuresMenu.textContent).toContain('Resume');
  });

  it('does not redirect completed users to onboarding when onboarding status refresh fails', async () => {
    localStorage.setItem('token', 'token');
    authAPI.getOnboardingStatus.mockRejectedValueOnce(new Error('network error'));

    await renderApp();

    expect(container.textContent).toContain('Home Page');
    expect(container.textContent).not.toContain('Onboarding Page');
  });

  it('opens Features dropdown on hover and closes on mouse leave', async () => {
    localStorage.setItem('token', 'token');

    await renderApp();

    const featuresMenu = container.querySelector('[data-testid="features-menu"]');
    expect(featuresMenu).not.toBeNull();

    expect(container.querySelector('#features-menu-panel')).toBeNull();

    await act(async () => {
      featuresMenu.dispatchEvent(new MouseEvent('mouseover', { bubbles: true }));
    });

    expect(container.querySelector('#features-menu-panel')).not.toBeNull();
    expect(featuresMenu.textContent).toContain('Discover');
    expect(featuresMenu.textContent).toContain('Calendar');
    expect(featuresMenu.textContent).toContain('Resume');

    await act(async () => {
      featuresMenu.dispatchEvent(new MouseEvent('mouseout', { bubbles: true, relatedTarget: document.body }));
    });
    await act(async () => {
      await new Promise((resolve) => setTimeout(resolve, 150));
    });

    expect(container.querySelector('#features-menu-panel')).toBeNull();
  });

  it('keeps Features dropdown open when pointer quickly re-enters', async () => {
    jest.useFakeTimers();
    try {
      localStorage.setItem('token', 'token');

      await renderApp();

      const featuresMenu = container.querySelector('[data-testid="features-menu"]');
      expect(featuresMenu).not.toBeNull();

      await act(async () => {
        featuresMenu.dispatchEvent(new MouseEvent('mouseover', { bubbles: true }));
      });

      expect(container.querySelector('#features-menu-panel')).not.toBeNull();

      await act(async () => {
        featuresMenu.dispatchEvent(new MouseEvent('mouseout', { bubbles: true, relatedTarget: document.body }));
        featuresMenu.dispatchEvent(new MouseEvent('mouseover', { bubbles: true }));
        jest.advanceTimersByTime(150);
      });

      expect(container.querySelector('#features-menu-panel')).not.toBeNull();
    } finally {
      jest.useRealTimers();
    }
  });

  it('keeps calendar in Features when not authenticated', async () => {
    await renderApp();

    expect(container.textContent).toContain('SocialSecure');

    const featuresMenu = container.querySelector('[data-testid="features-menu"]');
    expect(featuresMenu).not.toBeNull();
    const featuresButton = featuresMenu.querySelector('button');
    expect(featuresButton).not.toBeNull();

    await act(async () => {
      featuresButton.click();
    });

    expect(featuresMenu.textContent).toContain('Calendar');
    expect(featuresMenu.textContent).not.toContain('Discover');
    expect(featuresMenu.textContent).not.toContain('Resume');
  });

  it('toggles the mobile nav menu with the hamburger button', async () => {
    localStorage.setItem('token', 'token');

    await renderApp();

    const mobileToggle = container.querySelector('button[aria-label="Toggle navigation menu"]');
    expect(mobileToggle).not.toBeNull();

    const navMenu = container.querySelector('#main-nav-menu');
    expect(navMenu).not.toBeNull();
    expect(navMenu.className).toContain('hidden');

    await act(async () => {
      mobileToggle.click();
    });

    expect(navMenu.className).toContain('absolute');
    expect(navMenu.className).toContain('top-full');
    expect(navMenu.className).not.toContain('hidden');
  });

  it('orders the primary nav links in a more familiar sequence', async () => {
    localStorage.setItem('token', 'token');

    await renderApp();

    const navItems = Array.from(container.querySelectorAll('#main-nav-menu > a, #main-nav-menu > div[data-testid="features-menu"] > button'))
      .map((node) => node.textContent.trim().replace('▾', '').trim());

    expect(navItems.indexOf('Social')).toBeGreaterThan(navItems.indexOf('Home'));
    expect(navItems.indexOf('Chat')).toBeGreaterThan(navItems.indexOf('Social'));
    expect(navItems.indexOf('Features')).toBeGreaterThan(navItems.indexOf('Chat'));
    expect(navItems.indexOf('News')).toBeGreaterThan(navItems.indexOf('Features'));
    expect(navItems.indexOf('Market')).toBeGreaterThan(navItems.indexOf('News'));
    expect(navItems.indexOf('Maps')).toBeGreaterThan(navItems.indexOf('Market'));
  });

  it('uses full-width main layout on the social route', async () => {
    localStorage.setItem('token', 'token');
    window.history.pushState({}, '', '/social');

    await renderApp();

    const main = container.querySelector('main');
    expect(main).not.toBeNull();
    expect(main.className).toContain('w-full');
    expect(main.className).not.toContain('container');
    expect(container.textContent).toContain('Social Page');
  });

});
