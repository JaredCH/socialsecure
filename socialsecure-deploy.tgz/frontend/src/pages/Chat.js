import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import toast from 'react-hot-toast';
import ChatComposerBar from '../components/chat/ChatComposerBar';
import ChatMessageList from '../components/chat/ChatMessageList';
import { authAPI, chatAPI, friendsAPI, moderationAPI, userAPI } from '../utils/api';
import { parseSlashCommand, runSlashCommand } from '../utils/chatCommands';
import {
  createWrappedRoomKeyPackage,
  decryptEnvelope,
  encryptEnvelope,
  ingestWrappedRoomKeyPackage,
  unlockOrCreateVault
} from '../utils/e2ee';

const CHANNELS = [
  { key: 'zip', label: 'Zip Rooms' },
  { key: 'dm', label: 'Direct Messages' },
  { key: 'profile', label: 'Profile Threads' }
];

const CHAT_THEMES = [
  {
    key: 'classic',
    label: 'Classic Light',
    shell: 'bg-slate-100 text-slate-900',
    panel: 'border-slate-300 bg-white/80 backdrop-blur-sm',
    panelGlass: 'border-slate-300 bg-white/85 backdrop-blur-md',
    accent: 'border border-blue-700 bg-blue-700 text-white hover:bg-blue-800',
    subtle: 'border-slate-300 bg-slate-100 text-slate-700 hover:bg-slate-200',
    input: 'border-slate-300 bg-white text-slate-900',
    messagesShell: 'border-slate-300 bg-gradient-to-b from-white to-slate-100',
    messageOwn: 'border-blue-700 bg-blue-100',
    messageOther: 'border-slate-400 bg-white'
  },
  {
    key: 'midnight',
    label: 'Midnight',
    shell: 'bg-slate-950 text-slate-100',
    panel: 'border-cyan-700/70 bg-slate-900/85 backdrop-blur-sm',
    panelGlass: 'border-cyan-700/70 bg-slate-900/90 backdrop-blur-md',
    accent: 'border border-cyan-400 bg-cyan-400 text-slate-950 hover:bg-cyan-300',
    subtle: 'border-cyan-800 bg-slate-800 text-cyan-100 hover:bg-slate-700',
    input: 'border-cyan-700 bg-slate-950 text-cyan-100',
    messagesShell: 'border-cyan-700 bg-gradient-to-b from-slate-900 to-slate-950',
    messageOwn: 'border-cyan-400 bg-cyan-400/20',
    messageOther: 'border-slate-600 bg-slate-800'
  },
  {
    key: 'ocean',
    label: 'Ocean',
    shell: 'bg-cyan-950 text-cyan-50',
    panel: 'border-cyan-700 bg-cyan-900/85 backdrop-blur-sm',
    panelGlass: 'border-cyan-600 bg-cyan-900/90 backdrop-blur-md',
    accent: 'border border-cyan-300 bg-cyan-300 text-cyan-950 hover:bg-cyan-200',
    subtle: 'border-cyan-700 bg-cyan-800 text-cyan-50 hover:bg-cyan-700',
    input: 'border-cyan-600 bg-cyan-950 text-cyan-50',
    messagesShell: 'border-cyan-700 bg-gradient-to-b from-cyan-900 to-cyan-950',
    messageOwn: 'border-cyan-300 bg-cyan-300/20',
    messageOther: 'border-cyan-700 bg-cyan-900'
  },
  {
    key: 'terminal',
    label: 'Terminal',
    shell: 'bg-zinc-950 text-lime-200',
    panel: 'border-lime-700 bg-zinc-900/90 backdrop-blur-sm',
    panelGlass: 'border-lime-700 bg-zinc-900/95 backdrop-blur-md',
    accent: 'border border-lime-500 bg-lime-500 text-zinc-950 hover:bg-lime-400',
    subtle: 'border-lime-800 bg-zinc-800 text-lime-200 hover:bg-zinc-700',
    input: 'border-lime-700 bg-zinc-950 text-lime-200',
    messagesShell: 'border-lime-700 bg-zinc-950',
    messageOwn: 'border-lime-500 bg-lime-500/20',
    messageOther: 'border-lime-800 bg-zinc-900'
  },
  {
    key: 'sunset',
    label: 'Sunset',
    shell: 'bg-orange-50 text-orange-950',
    panel: 'border-orange-300 bg-white/85 backdrop-blur-sm',
    panelGlass: 'border-orange-300 bg-white/95 backdrop-blur-md',
    accent: 'border border-orange-600 bg-orange-600 text-white hover:bg-orange-700',
    subtle: 'border-orange-300 bg-orange-100 text-orange-900 hover:bg-orange-200',
    input: 'border-orange-300 bg-white text-orange-950',
    messagesShell: 'border-orange-300 bg-gradient-to-b from-white to-orange-100',
    messageOwn: 'border-orange-600 bg-orange-200',
    messageOther: 'border-orange-300 bg-white'
  },
  {
    key: 'lavender',
    label: 'Lavender',
    shell: 'bg-violet-50 text-violet-950',
    panel: 'border-violet-300 bg-white/85 backdrop-blur-sm',
    panelGlass: 'border-violet-300 bg-white/95 backdrop-blur-md',
    accent: 'border border-violet-600 bg-violet-600 text-white hover:bg-violet-700',
    subtle: 'border-violet-300 bg-violet-100 text-violet-900 hover:bg-violet-200',
    input: 'border-violet-300 bg-white text-violet-950',
    messagesShell: 'border-violet-300 bg-gradient-to-b from-white to-violet-100',
    messageOwn: 'border-violet-600 bg-violet-200',
    messageOther: 'border-violet-300 bg-white'
  }
];

const getConversationLabel = (conversation) => {
  if (!conversation) return '';

  if (conversation.type === 'zip-room') {
    return conversation.title || (conversation.zipCode ? `Zip ${conversation.zipCode}` : 'Zip room');
  }

  if (conversation.type === 'dm') {
    return conversation.peer?.username
      ? `@${conversation.peer.username}`
      : (conversation.peer?.realName || 'Direct message');
  }

  if (conversation.type === 'profile-thread') {
    return conversation.profileUser?.username
      ? `@${conversation.profileUser.username}`
      : (conversation.title || 'Profile thread');
  }

  return conversation.title || 'Conversation';
};

const getPresenceState = (lastActiveAt) => {
  if (!lastActiveAt) return { label: 'Away', tone: 'bg-amber-400' };
  const ageMs = Date.now() - new Date(lastActiveAt).getTime();
  if (Number.isNaN(ageMs)) return { label: 'Away', tone: 'bg-amber-400' };
  return ageMs <= 5 * 60 * 1000
    ? { label: 'Online', tone: 'bg-emerald-400' }
    : { label: 'Away', tone: 'bg-amber-400' };
};

const HEX_COLOR_REGEX = /^#(?:[0-9a-f]{3}|[0-9a-f]{6})$/i;
const DEFAULT_CHAT_NAME_COLOR = '#2563eb';
const LONG_PRESS_DELAY_MS = 550;
const USER_MENU_WIDTH_PX = 240;
const USER_MENU_HEIGHT_PX = 220;
const DM_UNLOCK_COOKIE_NAME = 'socialsecure_dm_unlock_v1';
const DM_UNLOCK_CACHE_SECONDS = 30 * 60;
const LOCKED_DM_PLACEHOLDER = '🔒 Conversation locked. Unlock to view encrypted messages.';
const DM_OFFLINE_SELECTION_ERROR = 'dm_offline_mode_selected';

const readCookie = (name) => {
  const source = typeof document?.cookie === 'string' ? document.cookie : '';
  const prefix = `${name}=`;
  const entry = source.split(';').find((part) => part.trim().startsWith(prefix));
  if (!entry) return '';
  try {
    return decodeURIComponent(entry.trim().slice(prefix.length));
  } catch {
    return '';
  }
};

const writeCookie = (name, value, maxAgeSeconds) => {
  const secure = window.location.protocol === 'https:' ? '; Secure' : '';
  document.cookie = `${name}=${encodeURIComponent(value)}; Path=/; Max-Age=${Math.max(0, Number(maxAgeSeconds) || 0)}; SameSite=Strict${secure}`;
};

const clearCookie = (name) => {
  writeCookie(name, '', 0);
};

const readDmUnlockCache = () => {
  try {
    const parsed = JSON.parse(readCookie(DM_UNLOCK_COOKIE_NAME) || '{}');
    const expiresAt = Number(parsed?.expiresAt || 0);
    if (!Number.isFinite(expiresAt) || expiresAt <= Date.now()) {
      return { expiresAt: 0, conversationIds: [] };
    }
    const conversationIds = Array.isArray(parsed?.conversationIds)
      ? parsed.conversationIds.map((id) => String(id || '').trim()).filter(Boolean)
      : [];
    return { expiresAt, conversationIds };
  } catch {
    return { expiresAt: 0, conversationIds: [] };
  }
};

const writeDmUnlockCache = (conversationIds) => {
  const uniqueIds = Array.from(new Set(
    (Array.isArray(conversationIds) ? conversationIds : [])
      .map((id) => String(id || '').trim())
      .filter(Boolean)
  ));
  if (uniqueIds.length === 0) {
    clearCookie(DM_UNLOCK_COOKIE_NAME);
    return;
  }
  const expiresAt = Date.now() + (DM_UNLOCK_CACHE_SECONDS * 1000);
  writeCookie(
    DM_UNLOCK_COOKIE_NAME,
    JSON.stringify({ expiresAt, conversationIds: uniqueIds }),
    DM_UNLOCK_CACHE_SECONDS
  );
};

function Chat() {
  const [profile, setProfile] = useState(null);
  const [loadingHub, setLoadingHub] = useState(true);
  const [activeChannel, setActiveChannel] = useState('zip');
  const [hubData, setHubData] = useState({
    zip: { current: null, nearby: [] },
    dm: [],
    profile: []
  });
  const [activeConversationId, setActiveConversationId] = useState('');

  const [messages, setMessages] = useState([]);
  const [decryptedDmContentById, setDecryptedDmContentById] = useState({});
  const [messagesLoading, setMessagesLoading] = useState(false);
  const [messagesError, setMessagesError] = useState('');
  const [composerValue, setComposerValue] = useState('');
  const [sending, setSending] = useState(false);
  const [localTyping, setLocalTyping] = useState(false);

  const [dmQuery, setDmQuery] = useState('');
  const [dmSuggestions, setDmSuggestions] = useState([]);
  const [dmSearchLoading, setDmSearchLoading] = useState(false);

  const [roomQuery, setRoomQuery] = useState('');
  const [theme, setTheme] = useState(() => {
    try {
      const saved = localStorage.getItem('chatTheme');
      if (saved && CHAT_THEMES.some((t) => t.key === saved)) return saved;
    } catch {
      // ignore localStorage errors
    }
    return CHAT_THEMES[0].key;
  });
  const [nameColor, setNameColor] = useState(() => {
    try {
      const saved = localStorage.getItem('chatNameColor');
      if (saved && HEX_COLOR_REGEX.test(saved)) return saved;
    } catch {
      // ignore localStorage errors
    }
    return DEFAULT_CHAT_NAME_COLOR;
  });
  const [roomUsers, setRoomUsers] = useState([]);
  const [roomUsersLoading, setRoomUsersLoading] = useState(false);
  const [mobileWorkspaceOpen, setMobileWorkspaceOpen] = useState(false);
  const [themeMenuOpen, setThemeMenuOpen] = useState(false);
  const [dmOfflineState, setDmOfflineState] = useState('online');
  const [dmUnlockedByConversation, setDmUnlockedByConversation] = useState({});
  const [rememberDmUnlock, setRememberDmUnlock] = useState(() => {
    try {
      return localStorage.getItem('chatRememberDmUnlock') !== 'false';
    } catch {
      return true;
    }
  });
  const [strictDmLockMode, setStrictDmLockMode] = useState(() => {
    try {
      return localStorage.getItem('chatStrictDmLockMode') === 'true';
    } catch {
      return false;
    }
  });
  const [dmFriends, setDmFriends] = useState([]);
  const [dmFriendsLoading, setDmFriendsLoading] = useState(false);
  const [isOnline, setIsOnline] = useState(() => navigator.onLine !== false);
  const [passwordModalOpen, setPasswordModalOpen] = useState(false);
  const [passwordInput, setPasswordInput] = useState('');
  const [userContextMenu, setUserContextMenu] = useState({
    open: false,
    x: 0,
    y: 0,
    user: null
  });
  const userLongPressTimerRef = useRef(null);
  const e2eeSessionRef = useRef(null);
  const passwordResolverRef = useRef(null);

  const handleThemeChange = useCallback((nextTheme) => {
    if (!CHAT_THEMES.some((t) => t.key === nextTheme)) return;
    setTheme(nextTheme);
    try {
      localStorage.setItem('chatTheme', nextTheme);
    } catch {
      // ignore localStorage errors
    }
  }, []);

  const handleNameColorChange = useCallback((nextColor) => {
    if (!HEX_COLOR_REGEX.test(String(nextColor || ''))) return;
    setNameColor(nextColor);
    try {
      localStorage.setItem('chatNameColor', nextColor);
    } catch {
      // ignore localStorage errors
    }
  }, []);

  const conversationList = useMemo(() => {
    if (activeChannel === 'zip') {
      const entries = [];
      if (hubData.zip.current) entries.push(hubData.zip.current);
      if (Array.isArray(hubData.zip.nearby)) {
        entries.push(...hubData.zip.nearby);
      }
      return entries;
    }

    if (activeChannel === 'dm') {
      return Array.isArray(hubData.dm) ? hubData.dm : [];
    }

    return Array.isArray(hubData.profile) ? hubData.profile : [];
  }, [activeChannel, hubData]);

  const activeConversation = useMemo(
    () => conversationList.find((conversation) => String(conversation._id) === String(activeConversationId)) || null,
    [conversationList, activeConversationId]
  );

  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      setDmOfflineState('online');
      setDecryptedDmContentById({});
    };
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  useEffect(() => {
    setDecryptedDmContentById({});
    setDmOfflineState('online');
  }, [activeConversationId, activeConversation?.type]);

  useEffect(() => {
    if (!profile?._id) return;
    let cancelled = false;
    setDmFriendsLoading(true);
    friendsAPI.getFriends()
      .then(({ data }) => {
        if (cancelled) return;
        setDmFriends(Array.isArray(data?.friends) ? data.friends : []);
      })
      .catch(() => {
        if (!cancelled) setDmFriends([]);
      })
      .finally(() => {
        if (!cancelled) setDmFriendsLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [profile?._id]);

  useEffect(() => {
    try {
      localStorage.setItem('chatRememberDmUnlock', rememberDmUnlock ? 'true' : 'false');
    } catch {
      // ignore localStorage errors
    }
    if (!rememberDmUnlock) {
      clearCookie(DM_UNLOCK_COOKIE_NAME);
    }
  }, [rememberDmUnlock]);

  useEffect(() => {
    try {
      localStorage.setItem('chatStrictDmLockMode', strictDmLockMode ? 'true' : 'false');
    } catch {
      // ignore localStorage errors
    }
  }, [strictDmLockMode]);

  useEffect(() => {
    if (!activeConversationId || activeConversation?.type !== 'dm') return;
    const conversationId = String(activeConversationId);
    const cache = readDmUnlockCache();
    if (!cache.conversationIds.includes(conversationId)) return;
    setDmUnlockedByConversation((prev) => ({
      ...prev,
      [conversationId]: true
    }));
  }, [activeConversation?.type, activeConversationId]);

  useEffect(() => {
    if (!strictDmLockMode) return;
    clearCookie(DM_UNLOCK_COOKIE_NAME);
    setDmUnlockedByConversation({});
    setDecryptedDmContentById({});
    e2eeSessionRef.current = null;
  }, [strictDmLockMode]);

  const allRooms = useMemo(() => {
    const withSearchLabel = (room, channel) => {
      const label = getConversationLabel(room);
      return {
        ...room,
        __channel: channel,
        __label: label,
        __labelLower: label.toLowerCase()
      };
    };
    const zipRooms = [
      ...(hubData?.zip?.current ? [withSearchLabel(hubData.zip.current, 'zip')] : []),
      ...((hubData?.zip?.nearby || []).map((room) => withSearchLabel(room, 'zip')))
    ];
    const dmRooms = (hubData?.dm || []).map((room) => withSearchLabel(room, 'dm'));
    const profileRooms = (hubData?.profile || []).map((room) => withSearchLabel(room, 'profile'));
    return [...zipRooms, ...dmRooms, ...profileRooms];
  }, [hubData]);

  const activeTheme = useMemo(
    () => CHAT_THEMES.find((themeOption) => themeOption.key === theme) || CHAT_THEMES[0],
    [theme]
  );

  const resolvedZipCode = useMemo(
    () => profile?.zipCode || hubData?.zip?.current?.zipCode || null,
    [profile, hubData]
  );

  const renderedMessages = useMemo(() => {
    if (activeConversation?.type !== 'dm') return messages;
    if (!dmUnlockedByConversation[String(activeConversationId || '')]) {
      return messages.map((message) => {
        const decrypted = decryptedDmContentById[String(message._id)];
        if (dmOfflineState === 'decrypted_offline' && decrypted) {
          return {
            ...message,
            content: decrypted
          };
        }
        return {
          ...message,
          content: LOCKED_DM_PLACEHOLDER
        };
      });
    }
    return messages.map((message) => {
      const decrypted = decryptedDmContentById[String(message._id)];
      if (!decrypted) return message;
      return {
        ...message,
        content: decrypted
      };
    });
  }, [activeConversation?.type, activeConversationId, decryptedDmContentById, dmOfflineState, dmUnlockedByConversation, messages]);

  const sharedMediaSnippets = useMemo(
    () => renderedMessages.filter((message) => /\[[^\]]+\]|https?:\/\//i.test(message.content || '')).slice(-6),
    [renderedMessages]
  );

  const applyDefaultConversationSelection = (channelKey, data) => {
    if (channelKey === 'zip') {
      const next = data?.zip?.current || (data?.zip?.nearby || [])[0] || null;
      setActiveConversationId(next ? String(next._id) : '');
      return;
    }

    if (channelKey === 'dm') {
      const next = (data?.dm || [])[0] || null;
      setActiveConversationId(next ? String(next._id) : '');
      return;
    }

    const next = (data?.profile || [])[0] || null;
    setActiveConversationId(next ? String(next._id) : '');
  };

  const refreshHub = async (channelToKeep = activeChannel) => {
    const [{ data: me }, { data: conversationsData }] = await Promise.all([
      authAPI.getProfile(),
      chatAPI.getConversations()
    ]);

    setProfile(me.user || null);
    const nextData = conversationsData?.conversations || { zip: { current: null, nearby: [] }, dm: [], profile: [] };
    setHubData(nextData);

    const stillExists = (() => {
      if (!activeConversationId) return false;

      if (channelToKeep === 'zip') {
        const candidates = [nextData?.zip?.current, ...(nextData?.zip?.nearby || [])].filter(Boolean);
        return candidates.some((conversation) => String(conversation._id) === String(activeConversationId));
      }

      if (channelToKeep === 'dm') {
        return (nextData?.dm || []).some((conversation) => String(conversation._id) === String(activeConversationId));
      }

      return (nextData?.profile || []).some((conversation) => String(conversation._id) === String(activeConversationId));
    })();

    if (!stillExists) {
      applyDefaultConversationSelection(channelToKeep, nextData);
    }
  };

  useEffect(() => {
    const bootstrap = async () => {
      setLoadingHub(true);
      try {
        await refreshHub('zip');
      } catch (error) {
        toast.error(error.response?.data?.error || 'Failed to load chat hub');
      } finally {
        setLoadingHub(false);
      }
    };

    bootstrap();
  }, []);

  useEffect(() => {
    applyDefaultConversationSelection(activeChannel, hubData);
  }, [activeChannel, hubData]);

  useEffect(() => {
    const loadMessages = async () => {
      if (!activeConversationId) {
        setMessages([]);
        setMessagesError('');
        return;
      }

      setMessagesLoading(true);
      setMessagesError('');
      try {
        const { data } = await chatAPI.getConversationMessages(activeConversationId, 1, 100);
        setMessages(Array.isArray(data.messages) ? data.messages : []);
      } catch (error) {
        setMessages([]);
        setMessagesError(error.response?.data?.error || 'Failed to load conversation messages');
      } finally {
        setMessagesLoading(false);
      }
    };

    loadMessages();
  }, [activeConversationId]);

  useEffect(() => {
    const loadRoomUsers = async () => {
      if (!activeConversationId) {
        setRoomUsers([]);
        return;
      }

      setRoomUsersLoading(true);
      try {
        const { data } = await chatAPI.getConversationUsers(activeConversationId);
        setRoomUsers(Array.isArray(data?.users) ? data.users : []);
      } catch (error) {
        setRoomUsers([]);
        toast.error(error.response?.data?.error || 'Failed to load room users');
      } finally {
        setRoomUsersLoading(false);
      }
    };

    loadRoomUsers();
  }, [activeConversationId]);

  useEffect(() => {
    if (!composerValue.trim()) {
      setLocalTyping(false);
      return;
    }

    setLocalTyping(true);
    const timer = setTimeout(() => setLocalTyping(false), 1200);
    return () => clearTimeout(timer);
  }, [composerValue]);

  const ensureE2EESession = useCallback(async () => {
    if (e2eeSessionRef.current) {
      return e2eeSessionRef.current;
    }
    if (!profile?._id) {
      throw new Error('Profile is required to unlock encryption vault');
    }

    const encryptionPassword = await new Promise((resolve, reject) => {
      passwordResolverRef.current = { resolve, reject };
      setPasswordInput('');
      setPasswordModalOpen(true);
    });

    const { session } = await unlockOrCreateVault({
      userId: profile._id,
      password: encryptionPassword
    });
    const registerPayload = await session.getRegisterPayload();
    await chatAPI.registerDeviceKeys(registerPayload);
    e2eeSessionRef.current = session;
    return session;
  }, [profile?._id]);

  useEffect(() => {
    if (!activeConversationId || activeConversation?.type !== 'dm') return;
    if (!dmUnlockedByConversation[String(activeConversationId)]) return;
    const encryptedMessages = messages.filter((message) => message?.e2ee?.ciphertext);
    if (encryptedMessages.length === 0) return;
    const pendingMessages = encryptedMessages.filter((message) => !decryptedDmContentById[String(message._id)]);
    if (pendingMessages.length === 0) return;

    let cancelled = false;
    const decryptMessages = async () => {
      try {
        const session = await ensureE2EESession();
        const decryptedEntries = {};
        for (const message of pendingMessages) {
          try {
            decryptedEntries[String(message._id)] = await decryptEnvelope({
              session,
              roomId: activeConversationId,
              envelope: message.e2ee
            });
          } catch {
            // keep encrypted placeholder when key is unavailable
          }
        }
        if (!cancelled && Object.keys(decryptedEntries).length > 0) {
          setDecryptedDmContentById((prev) => ({
            ...prev,
            ...decryptedEntries
          }));
        }
      } catch {
        // user can choose offline mode from unlock prompt and decrypt later
      }
    };

    decryptMessages();
    return () => {
      cancelled = true;
    };
  }, [
    activeConversation?.type,
    activeConversationId,
    decryptedDmContentById,
    dmUnlockedByConversation,
    ensureE2EESession,
    messages
  ]);

  const handlePasswordUnlock = useCallback(() => {
    const resolver = passwordResolverRef.current;
    if (!resolver) return;
    if (!passwordInput) {
      toast.error('Encryption password is required');
      return;
    }
    passwordResolverRef.current = null;
    setPasswordModalOpen(false);
    resolver.resolve(passwordInput);
  }, [passwordInput]);

  const handlePasswordCancel = useCallback(() => {
    const resolver = passwordResolverRef.current;
    if (!resolver) return;
    passwordResolverRef.current = null;
    setPasswordModalOpen(false);
    resolver.reject(new Error('Encryption password is required'));
  }, []);

  const handleUseOfflineMode = useCallback(() => {
    const resolver = passwordResolverRef.current;
    if (!resolver) return;
    passwordResolverRef.current = null;
    setPasswordModalOpen(false);
    resolver.reject(new Error(DM_OFFLINE_SELECTION_ERROR));
  }, []);

  const persistDmUnlockCache = useCallback((conversationId, shouldCache) => {
    const normalizedId = String(conversationId || '').trim();
    if (!normalizedId) return;
    const existing = readDmUnlockCache();
    const nextSet = new Set(existing.conversationIds);
    if (shouldCache) {
      nextSet.add(normalizedId);
    } else {
      nextSet.delete(normalizedId);
    }
    writeDmUnlockCache([...nextSet]);
  }, []);

  const hydrateConversationKeys = useCallback(async ({ conversationId, session }) => {
    const { data } = await chatAPI.syncConversationKeyPackages(conversationId, session.deviceId);
    const packages = Array.isArray(data?.packages) ? data.packages : [];
    for (const pkg of packages) {
      await ingestWrappedRoomKeyPackage({ session, pkg });
    }
    if (packages.length > 0) {
      await session.persist();
    }
  }, []);

  const prepareOfflineDmData = useCallback(async () => {
    if (!activeConversationId || activeConversation?.type !== 'dm') {
      return;
    }
    setDmOfflineState('downloading_encrypted');
    try {
      await chatAPI.getConversationMessages(activeConversationId, 1, 100);
      if (isOnline && e2eeSessionRef.current) {
        await hydrateConversationKeys({ conversationId: activeConversationId, session: e2eeSessionRef.current });
      }
      setDmOfflineState('ready_offline');
      toast.success('Encrypted DM data is cached. Disconnect from the internet before decrypting.');
    } catch (error) {
      setDmOfflineState('online');
      toast.error(error.response?.data?.error || error.message || 'Failed to prepare offline DM data');
    }
  }, [activeConversation?.type, activeConversationId, hydrateConversationKeys, isOnline]);

  const handleSend = async (event) => {
    event.preventDefault();
    const trimmed = composerValue.trim();
    if (!trimmed || !activeConversationId) return;

    const parsed = parseSlashCommand(trimmed);
    let contentToSend = trimmed;
    if (parsed) {
      const result = runSlashCommand({
        command: parsed.command,
        argsRaw: parsed.argsRaw,
        username: profile?.username || profile?.realName || 'user'
      });
      if (!result.ok) {
        toast.error(result.error || 'Invalid slash command');
        return;
      }
      contentToSend = result.payload?.plaintext || trimmed;
    }

    setSending(true);
    try {
      let data;
      if (activeConversation?.type === 'dm') {
        const session = await ensureE2EESession();
        await hydrateConversationKeys({ conversationId: activeConversationId, session });
        const existingKey = session.getLatestRoomKey(activeConversationId);
        const keyVersion = existingKey?.keyVersion || 1;
        const roomKey = existingKey?.keyBytes || session.createRoomKey();
        if (!existingKey) {
          session.setRoomKey(activeConversationId, keyVersion, roomKey);
        }

        const envelope = await encryptEnvelope({
          session,
          roomId: activeConversationId,
          keyVersion,
          roomKey,
          plaintext: contentToSend
        });

        const devicesResponse = await chatAPI.getConversationDevices(activeConversationId);
        const allDevices = Array.isArray(devicesResponse?.data?.devices) ? devicesResponse.data.devices : [];
        const targetDevices = allDevices.filter((device) => (
          !(String(device.userId) === String(profile?._id) && String(device.deviceId) === String(session.deviceId))
        ));

        if (targetDevices.length > 0) {
          const packages = await Promise.all(targetDevices.map((device) => createWrappedRoomKeyPackage({
            session,
            roomId: activeConversationId,
            keyVersion,
            roomKey,
            recipientUserId: String(device.userId),
            recipientDeviceId: String(device.deviceId)
          })));
          await chatAPI.publishConversationKeyPackages(activeConversationId, packages);
        }

        const response = await chatAPI.sendConversationE2EEMessage(activeConversationId, {
          e2ee: envelope,
          messageType: 'text'
        });
        data = response.data;
        await session.persist();
      } else {
        const response = await chatAPI.sendConversationMessage(activeConversationId, {
          content: contentToSend,
          senderNameColor: nameColor
        });
        data = response.data;
      }

      setMessages((prev) => [...prev, data.message]);
      setComposerValue('');
      setLocalTyping(false);
      await refreshHub(activeChannel);
    } catch (error) {
      toast.error(error.response?.data?.error || 'Failed to send message');
    } finally {
      setSending(false);
    }
  };

  const handleStartDM = useCallback(async (targetUserId) => {
    try {
      const { data } = await chatAPI.startDM(targetUserId);
      await refreshHub('dm');
      setActiveChannel('dm');
      setActiveConversationId(String(data.conversation._id));
      setDmSuggestions([]);
      setDmQuery('');
      setMobileWorkspaceOpen(true);
    } catch (error) {
      toast.error(error.response?.data?.error || 'Failed to start DM');
    }
  }, [refreshHub]);

  const handleUnlockActiveDM = useCallback(async () => {
    if (!activeConversationId || activeConversation?.type !== 'dm') return;
    try {
      const session = await ensureE2EESession();
      await hydrateConversationKeys({ conversationId: activeConversationId, session });
      setDmUnlockedByConversation((prev) => ({
        ...prev,
        [String(activeConversationId)]: true
      }));
      if (rememberDmUnlock && !strictDmLockMode) {
        persistDmUnlockCache(activeConversationId, true);
      }
      toast.success('Direct message unlocked.');
    } catch (error) {
      if (error?.message === DM_OFFLINE_SELECTION_ERROR) {
        await prepareOfflineDmData();
        return;
      }
      toast.error(error.response?.data?.error || error.message || 'Failed to unlock direct message');
    }
  }, [
    activeConversation?.type,
    activeConversationId,
    ensureE2EESession,
    hydrateConversationKeys,
    prepareOfflineDmData,
    persistDmUnlockCache,
    rememberDmUnlock,
    strictDmLockMode
  ]);

  const handleLockActiveDM = useCallback(() => {
    if (!activeConversationId || activeConversation?.type !== 'dm') return;
    setDmUnlockedByConversation((prev) => ({
      ...prev,
      [String(activeConversationId)]: false
    }));
    setDecryptedDmContentById({});
    setDmOfflineState('online');
    persistDmUnlockCache(activeConversationId, false);
    e2eeSessionRef.current = null;
    toast.success('Direct message locked.');
  }, [activeConversation?.type, activeConversationId, persistDmUnlockCache]);

  const handleClearDmUnlockCache = useCallback(() => {
    clearCookie(DM_UNLOCK_COOKIE_NAME);
    setDmUnlockedByConversation({});
    setDecryptedDmContentById({});
    e2eeSessionRef.current = null;
    toast.success('Saved DM unlock access reset.');
  }, []);

  const handleGoOffline = useCallback(async () => {
    await prepareOfflineDmData();
  }, [prepareOfflineDmData]);

  const handleDecryptOfflineMessages = useCallback(async () => {
    if (activeConversation?.type !== 'dm') return;
    if (dmOfflineState !== 'ready_offline') return;
    if (isOnline) {
      toast('Disconnect from the internet before decrypting offline messages.');
      return;
    }
    try {
      const session = await ensureE2EESession();
      const decryptedEntries = {};
      for (const message of messages) {
        if (!message?.e2ee?.ciphertext) continue;
        try {
          decryptedEntries[String(message._id)] = await decryptEnvelope({
            session,
            roomId: activeConversationId,
            envelope: message.e2ee
          });
        } catch {
          // keep encrypted placeholder when key is unavailable
        }
      }
      setDecryptedDmContentById(decryptedEntries);
      setDmOfflineState('decrypted_offline');
      toast.success('Offline DM decrypt complete.');
    } catch (error) {
      toast.error(error.message || 'Failed to decrypt offline messages');
    }
  }, [activeConversation?.type, activeConversationId, dmOfflineState, ensureE2EESession, isOnline, messages]);

  const handleReturnOnline = useCallback(() => {
    setDmOfflineState('online');
    setDecryptedDmContentById({});
    e2eeSessionRef.current = null;
    if (!isOnline) {
      toast('Reconnect to network to resume live DM sync.');
    } else {
      toast.success('Returned online and wiped decrypted offline DM state.');
    }
  }, [isOnline]);

  const handleOpenProfileThread = useCallback(async (targetUserId) => {
    try {
      const { data } = await chatAPI.getProfileThread(targetUserId);
      const conversationId = data?.conversation?._id ? String(data.conversation._id) : '';
      await refreshHub('profile');
      setActiveChannel('profile');
      if (conversationId) {
        setActiveConversationId(conversationId);
      }
      setMobileWorkspaceOpen(true);
    } catch (error) {
      toast.error(error.response?.data?.error || 'Failed to open profile thread');
    }
  }, [refreshHub]);

  useEffect(() => {
    if (!profile?._id) return;

    const params = new URLSearchParams(window.location.search);
    const profileThreadTarget = params.get('profile');
    const directMessageTarget = params.get('dm');
    if (profileThreadTarget && String(profileThreadTarget) !== String(profile._id)) {
      handleOpenProfileThread(profileThreadTarget).finally(() => {
        window.history.replaceState({}, '', '/chat');
      });
      return;
    }

    if (!directMessageTarget || String(directMessageTarget) === String(profile._id)) {
      return;
    }

    handleStartDM(directMessageTarget).finally(() => {
      window.history.replaceState({}, '', '/chat');
    });
  }, [profile?._id, handleOpenProfileThread, handleStartDM]);

  const openUserContextMenu = (event, user, point) => {
    if (event?.preventDefault) event.preventDefault();
    const fallbackRect = event?.currentTarget?.getBoundingClientRect?.();
    const x = Number.isFinite(point?.x)
      ? point.x
      : Number.isFinite(event?.clientX)
        ? event.clientX
        : (fallbackRect?.left || 0) + ((fallbackRect?.width || 0) / 2);
    const y = Number.isFinite(point?.y)
      ? point.y
      : Number.isFinite(event?.clientY)
        ? event.clientY
        : (fallbackRect?.top || 0) + ((fallbackRect?.height || 0) / 2);
    setUserContextMenu({
      open: true,
      x: Math.max(8, Math.min(window.innerWidth - USER_MENU_WIDTH_PX, x)),
      y: Math.max(8, Math.min(window.innerHeight - USER_MENU_HEIGHT_PX, y)),
      user
    });
  };

  const closeUserContextMenu = () => {
    setUserContextMenu((prev) => ({ ...prev, open: false }));
  };

  const handleViewUserSocial = (user) => {
    const identifier = user?.username || user?._id;
    if (!identifier) return;
    window.open(`/social?user=${encodeURIComponent(identifier)}`, '_blank', 'noopener,noreferrer');
  };

  const handleRequestFriendship = async (user) => {
    if (!user?._id || String(user._id) === String(profile?._id)) return;
    try {
      await friendsAPI.sendRequest(user._id);
      toast.success(`Friend request sent to @${user.username || user.realName || 'user'}`);
    } catch (error) {
      toast.error(error.response?.data?.error || 'Failed to send friend request');
    }
  };

  const handleBlockIgnore = async (user) => {
    if (!user?._id || String(user._id) === String(profile?._id)) return;
    try {
      await moderationAPI.blockUser(user._id, 'Blocked from chat user context menu');
      toast.success(`Blocked @${user.username || user.realName || 'user'}`);
    } catch (error) {
      toast.error(error.response?.data?.error || 'Failed to block user');
    }
  };

  useEffect(() => {
    const query = dmQuery.trim();
    if (query.length < 2) {
      setDmSuggestions([]);
      setDmSearchLoading(false);
      return;
    }

    let cancelled = false;
    const handle = setTimeout(() => {
      setDmSearchLoading(true);
      userAPI.search(query)
        .then(({ data }) => {
          if (cancelled) return;
          const users = Array.isArray(data?.users) ? data.users : [];
          setDmSuggestions(users.filter((user) => String(user._id) !== String(profile?._id)));
        })
        .catch((error) => {
          if (cancelled) return;
          setDmSuggestions([]);
          toast.error(error.response?.data?.error || 'Failed to search users');
        })
        .finally(() => {
          if (!cancelled) setDmSearchLoading(false);
        });
    }, 300);

    return () => {
      clearTimeout(handle);
      cancelled = true;
    };
  }, [dmQuery, profile]);

  useEffect(() => {
    if (!userContextMenu.open) return undefined;
    const handleWindowClick = () => setUserContextMenu((prev) => ({ ...prev, open: false }));
    const handleEscape = (event) => {
      if (event.key === 'Escape') {
        setUserContextMenu((prev) => ({ ...prev, open: false }));
      }
    };
    window.addEventListener('click', handleWindowClick);
    window.addEventListener('keydown', handleEscape);
    return () => {
      window.removeEventListener('click', handleWindowClick);
      window.removeEventListener('keydown', handleEscape);
    };
  }, [userContextMenu.open]);

  useEffect(() => {
    if (!themeMenuOpen) return undefined;
    const handleWindowClick = () => setThemeMenuOpen(false);
    const handleEscape = (event) => {
      if (event.key === 'Escape') setThemeMenuOpen(false);
    };
    window.addEventListener('click', handleWindowClick);
    window.addEventListener('keydown', handleEscape);
    return () => {
      window.removeEventListener('click', handleWindowClick);
      window.removeEventListener('keydown', handleEscape);
    };
  }, [themeMenuOpen]);

  useEffect(() => () => {
    if (userLongPressTimerRef.current) {
      clearTimeout(userLongPressTimerRef.current);
      userLongPressTimerRef.current = null;
    }
    if (passwordResolverRef.current) {
      passwordResolverRef.current.reject(new Error('Encryption password prompt cancelled'));
      passwordResolverRef.current = null;
    }
  }, []);

  const roomSuggestions = useMemo(() => {
    const query = roomQuery.trim().toLowerCase();
    if (query.length < 2) return [];
    return allRooms
      .filter((room) => room.__labelLower.includes(query))
      .slice(0, 8);
  }, [roomQuery, allRooms]);

  const selectRoomSuggestion = (room) => {
    setActiveChannel(room.__channel || 'zip');
    setActiveConversationId(String(room._id));
    setRoomQuery(room.__label || getConversationLabel(room));
    setMobileWorkspaceOpen(true);
  };

  const conversationPresence = getPresenceState(activeConversation?.lastMessageAt);
  const activeConversationUser = useMemo(() => {
    if (!activeConversation) return null;
    if (activeConversation.type === 'dm') return activeConversation.peer || null;
    if (activeConversation.type === 'profile-thread') return activeConversation.profileUser || null;
    return null;
  }, [activeConversation]);

  if (loadingHub) {
    return (
      <div className="h-full w-full grid place-items-center bg-white">
        <div className="text-sm opacity-80">Loading unified chat hub...</div>
      </div>
    );
  }

  return (
    <div className={`h-full w-full min-h-0 overflow-hidden flex flex-col ${activeTheme.shell}`}>
      <header className={`border-b px-2 py-1.5 md:px-3 ${activeTheme.panelGlass}`}>
        <div className="flex items-center justify-between gap-2">
          <div className="min-w-0">
            <h2 className="truncate text-sm font-semibold">Chat</h2>
            <p className="truncate text-[10px] opacity-80">
              @{profile?.username || 'you'}{resolvedZipCode ? ` • Zip ${resolvedZipCode}` : ''}
            </p>
          </div>
        </div>
      </header>

      <div className="grid flex-1 min-h-0 grid-cols-1 lg:grid-cols-[1.5fr_9fr_1.5fr]">
        <aside
          className={[
            mobileWorkspaceOpen ? 'hidden' : 'flex',
            'min-h-0 flex-col border-b p-2 md:p-3 lg:flex lg:border-b-0 lg:border-r',
            activeTheme.panel
          ].join(' ')}
        >
          <div className="sticky top-0 z-10 space-y-3 pb-3">
            <h3 className="font-semibold">Conversations</h3>
            <div className="grid grid-cols-3 gap-2">
              {CHANNELS.map((channel) => (
                <button
                  key={channel.key}
                  type="button"
                  onClick={() => setActiveChannel(channel.key)}
                  className={`rounded border px-2 py-2 text-xs md:text-sm transition ${activeChannel === channel.key ? activeTheme.subtle : 'opacity-80 hover:opacity-100'}`}
                >
                  {channel.label}
                </button>
              ))}
            </div>
          </div>

          <div className="mt-2 space-y-3 overflow-y-auto pr-1">
            <div className="space-y-2">
              <label className="text-xs font-semibold block">Find Rooms</label>
              <input
                value={roomQuery}
                onChange={(event) => setRoomQuery(event.target.value)}
                className={`w-full border rounded p-2 text-sm ${activeTheme.input}`}
                placeholder="Search room names..."
              />
              {roomSuggestions.length > 0 ? (
                <ul className={`max-h-36 overflow-auto border rounded divide-y text-xs ${activeTheme.panelGlass}`}>
                  {roomSuggestions.map((room) => (
                    <li key={String(room._id)}>
                      <button
                        type="button"
                        onClick={() => selectRoomSuggestion(room)}
                        className="w-full text-left p-2 hover:opacity-80"
                      >
                        {room.__label || getConversationLabel(room)}
                      </button>
                    </li>
                  ))}
                </ul>
              ) : null}
            </div>

            <div className="space-y-2 border-t pt-3">
              <label className="text-xs font-semibold block">Find Users (DM)</label>
              <input
                value={dmQuery}
                onChange={(event) => setDmQuery(event.target.value)}
                className={`w-full border rounded p-2 text-sm ${activeTheme.input}`}
                placeholder="Search username or name..."
              />
              {dmSearchLoading ? (
                <p className="text-xs opacity-80">Searching users...</p>
              ) : null}
              {dmSuggestions.length > 0 ? (
                <ul className={`max-h-40 overflow-auto border rounded divide-y text-xs ${activeTheme.panelGlass}`}>
                  {dmSuggestions.map((user) => (
                    <li key={String(user._id)} className="p-2 flex justify-between items-center gap-2">
                      <span>@{user.username || user.realName || 'user'}</span>
                      <button
                        type="button"
                        onClick={() => handleStartDM(user._id)}
                        className={`rounded border px-2 py-1 ${activeTheme.subtle}`}
                      >
                        Start DM
                      </button>
                    </li>
                  ))}
                </ul>
              ) : null}
            </div>

            <div className="space-y-2 border-t pt-3">
              {activeChannel === 'dm' ? (
                <>
                  <p className="text-xs font-semibold">Friends ({dmFriends.length})</p>
                  {dmFriendsLoading ? (
                    <p className="text-xs opacity-80">Loading friends...</p>
                  ) : dmFriends.length === 0 ? (
                    <p className="text-xs opacity-80">No friends found yet.</p>
                  ) : (
                    <ul className={`max-h-40 overflow-auto border rounded divide-y text-xs ${activeTheme.panelGlass}`}>
                      {dmFriends.map((friend) => (
                        <li key={String(friend._id)} className="p-2 flex justify-between items-center gap-2">
                          <span>@{friend.username || friend.realName || 'friend'}</span>
                          <button
                            type="button"
                            onClick={() => handleStartDM(friend._id)}
                            className={`rounded border px-2 py-1 ${activeTheme.subtle}`}
                          >
                            Message
                          </button>
                        </li>
                      ))}
                    </ul>
                  )}
                </>
              ) : null}
            </div>

            <div className="space-y-2 border-t pt-3">
              <p className="text-xs font-semibold">Rooms in this channel</p>
              {conversationList.length === 0 ? (
                <p className="text-xs opacity-80">No rooms available in this channel yet.</p>
              ) : (
                <ul className="space-y-2">
                  {conversationList.map((conversation) => {
                    const selected = String(conversation._id) === String(activeConversationId);
                    const status = getPresenceState(conversation.lastMessageAt);
                    return (
                      <li key={String(conversation._id)}>
                        <button
                          type="button"
                          onClick={() => {
                            setActiveConversationId(String(conversation._id));
                            setMobileWorkspaceOpen(true);
                          }}
                          className={`w-full rounded border px-3 py-2 text-left text-sm transition ${selected ? activeTheme.subtle : 'hover:opacity-85'}`}
                        >
                          <div className="flex items-center justify-between gap-2">
                            <span className="font-medium">{getConversationLabel(conversation)}</span>
                            <span className="inline-flex items-center gap-1 text-[10px] font-mono uppercase">
                              <span className={`h-2 w-2 rounded-full ${status.tone}`} />
                              {status.label}
                            </span>
                          </div>
                          {conversation.lastMessageAt ? (
                            <div className="text-[11px] opacity-80 font-mono">Last active {new Date(conversation.lastMessageAt).toLocaleString()}</div>
                          ) : null}
                        </button>
                      </li>
                    );
                  })}
                </ul>
              )}
            </div>
          </div>
        </aside>

        <section
          className={[
            mobileWorkspaceOpen ? 'flex' : 'hidden',
            'min-h-0 flex-col border-b px-2 pb-2 pt-1 md:p-3 lg:flex lg:border-b-0 lg:border-r',
            activeTheme.panel
          ].join(' ')}
        >
          <header className={`relative sticky top-0 z-40 mb-2 rounded border px-2 py-1.5 ${activeTheme.panelGlass}`}>
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setMobileWorkspaceOpen(false)}
                  className={`rounded border px-2 py-1 text-xs lg:hidden ${activeTheme.subtle}`}
                  aria-label="Back to conversations"
                >
                  ← Back
                </button>
                <div>
                  <h3 className="text-sm font-semibold">{activeConversation ? getConversationLabel(activeConversation) : 'Select a room'}</h3>
                  <p className="text-[10px] font-mono opacity-75">Mobile chat</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="relative">
                  <button
                    type="button"
                    onClick={(event) => {
                      event.stopPropagation();
                      setThemeMenuOpen((open) => !open);
                    }}
                    className={`rounded border px-2 py-1 text-sm ${activeTheme.subtle}`}
                    aria-label="Open chat theme menu"
                    aria-expanded={themeMenuOpen}
                  >
                    🎨
                    <span className="sr-only">Theme menu</span>
                  </button>
                  {themeMenuOpen ? (
                    <div
                      className={`absolute right-0 top-9 z-50 min-w-40 rounded border p-1 text-xs shadow-xl ${activeTheme.panelGlass}`}
                      onClick={(event) => event.stopPropagation()}
                    >
                      {CHAT_THEMES.map((themeOption) => (
                        <button
                          key={themeOption.key}
                          type="button"
                          onClick={() => {
                            handleThemeChange(themeOption.key);
                            setThemeMenuOpen(false);
                          }}
                          className={`flex w-full items-center justify-between rounded px-2 py-1 text-left hover:opacity-80 ${theme === themeOption.key ? 'font-semibold' : ''}`}
                        >
                          <span>{themeOption.label}</span>
                          {theme === themeOption.key ? <span>✓</span> : null}
                        </button>
                      ))}
                    </div>
                  ) : null}
                </div>
                <label className="sr-only" htmlFor="chat-theme-select-fallback">Theme</label>
                <select
                  id="chat-theme-select-fallback"
                  value={theme}
                  onChange={(event) => handleThemeChange(event.target.value)}
                  className="sr-only"
                >
                  {CHAT_THEMES.map((themeOption) => (
                    <option key={themeOption.key} value={themeOption.key}>
                      {themeOption.label}
                    </option>
                  ))}
                </select>
                <label className="text-xs font-medium flex items-center">
                  <input
                    type="color"
                    value={nameColor}
                    onChange={(event) => handleNameColorChange(event.target.value)}
                    className="h-7 w-8 rounded border border-slate-300 bg-transparent p-0.5"
                    aria-label="Set your chat name color"
                  />
                </label>
                {activeConversationUser?.username ? (
                  <a
                    href={`/social?user=${encodeURIComponent(activeConversationUser.username)}`}
                    className={`rounded border px-2 py-1 text-[10px] ${activeTheme.subtle}`}
                    aria-label={`View @${activeConversationUser.username} profile`}
                  >
                    👤
                  </a>
                ) : null}
                {activeConversation ? (
                  <span className="inline-flex items-center gap-1 text-[10px] font-mono uppercase">
                    <span className={`h-2 w-2 rounded-full ${conversationPresence.tone}`} />
                    {conversationPresence.label}
                  </span>
                ) : null}
                {activeConversation?.type === 'dm' ? (
                  <div className="inline-flex items-center gap-1">
                    <button
                      type="button"
                      onClick={dmUnlockedByConversation[String(activeConversationId)] ? handleLockActiveDM : handleUnlockActiveDM}
                      className={`rounded border px-2 py-1 text-[10px] ${activeTheme.subtle}`}
                    >
                      {dmUnlockedByConversation[String(activeConversationId)] ? 'Lock DM' : 'Unlock DM'}
                    </button>
                    <button
                      type="button"
                      onClick={handleGoOffline}
                      disabled={dmOfflineState !== 'online'}
                      className={`rounded border px-2 py-1 text-[10px] ${activeTheme.subtle} disabled:opacity-50`}
                    >
                      {dmOfflineState === 'downloading_encrypted' ? 'Downloading…' : 'Go Offline'}
                    </button>
                    <button
                      type="button"
                      onClick={handleDecryptOfflineMessages}
                      disabled={dmOfflineState !== 'ready_offline'}
                      className={`rounded border px-2 py-1 text-[10px] ${activeTheme.subtle} disabled:opacity-50`}
                    >
                      Decrypt Offline Messages
                    </button>
                    <button
                      type="button"
                      onClick={handleReturnOnline}
                      disabled={dmOfflineState === 'online'}
                      className={`rounded border px-2 py-1 text-[10px] ${activeTheme.subtle} disabled:opacity-50`}
                    >
                      Return Online
                    </button>
                  </div>
                ) : null}
              </div>
            </div>
            {activeConversation?.type === 'dm' && dmOfflineState === 'ready_offline' && isOnline ? (
              <div className={`mt-2 rounded border px-2 py-1 text-[10px] ${activeTheme.panelGlass}`}>
                Offline package ready. Disconnect from the internet, then use “Decrypt Offline Messages”.
              </div>
            ) : null}
          </header>

          {messagesError ? (
            <div className="mb-3 rounded border border-red-400 bg-red-50 p-2 text-sm text-red-700">{messagesError}</div>
          ) : null}

          <ChatMessageList
            conversationId={activeConversationId}
            messages={renderedMessages}
            loading={messagesLoading}
            profile={profile}
            theme={activeTheme}
            onOpenUserMenu={openUserContextMenu}
            longPressDelayMs={LONG_PRESS_DELAY_MS}
          />

          <div className="mt-1 space-y-1">
            {localTyping ? (
              <div className="inline-flex items-center gap-1 rounded border px-2 py-1 text-xs font-mono opacity-80">
                <span className="animate-pulse">●</span>
                <span className="animate-pulse [animation-delay:120ms]">●</span>
                <span className="animate-pulse [animation-delay:240ms]">●</span>
                You are typing...
              </div>
            ) : null}

            <div className="sticky bottom-0 pb-[env(safe-area-inset-bottom)]">
              <ChatComposerBar
                composerValue={composerValue}
                setComposerValue={setComposerValue}
                onSubmit={handleSend}
                disabled={
                  !activeConversationId
                  || (activeConversation?.type === 'dm' && (
                    !dmUnlockedByConversation[String(activeConversationId)]
                    || dmOfflineState !== 'online'
                  ))
                }
                sending={sending}
                theme={activeTheme}
                onComposerError={(message) => toast.error(message)}
              />
            </div>
          </div>
        </section>

        <aside className={`hidden min-h-0 flex-col p-2 md:p-3 lg:flex ${activeTheme.panel}`}>
          <div className={`sticky top-0 z-10 rounded border p-3 ${activeTheme.panelGlass}`}>
            <h3 className="font-semibold">Conversation Details</h3>
            {activeConversation ? (
              <>
                <p className="text-xs opacity-80">{getConversationLabel(activeConversation)}</p>
                <p className="text-[11px] font-mono opacity-80 mt-1">Status: {conversationPresence.label}</p>
              </>
            ) : (
              <p className="text-xs opacity-80">Select a room to view details.</p>
            )}
            <p className="mt-2 text-xs opacity-80">About: Retro-modern workspace with neon borders and classic buddy presence markers.</p>
          </div>

          <div className="mt-3 min-h-0 flex-1 space-y-3 overflow-y-auto">
            <section className={`rounded border p-2 ${activeTheme.panelGlass}`}>
              <h4 className="text-sm font-semibold">Users in Room</h4>
              <p className="mt-1 text-[11px] opacity-80">Click, right-click, or long-press a user for quick actions.</p>
              <div className="mt-2 rounded border overflow-auto max-h-56">
                {roomUsersLoading ? (
                  <p className="p-2 text-xs opacity-80">Loading users...</p>
                ) : roomUsers.length === 0 ? (
                  <p className="p-2 text-xs opacity-80">No users to display.</p>
                ) : (
                  <ul className="divide-y">
                    {roomUsers.map((user) => {
                      const status = getPresenceState(user.lastActiveAt || user.updatedAt || user.lastSeenAt);
                      return (
                        <li
                          key={String(user._id)}
                          className="flex cursor-pointer items-center justify-between gap-2 p-2 text-sm"
                          onClick={(event) => openUserContextMenu(event, user)}
                          onContextMenu={(event) => openUserContextMenu(event, user)}
                          onTouchStart={(event) => {
                            const touch = event.touches?.[0];
                            if (!touch) return;
                            if (userLongPressTimerRef.current) clearTimeout(userLongPressTimerRef.current);
                            userLongPressTimerRef.current = setTimeout(() => {
                              openUserContextMenu(event, user, { x: touch.clientX, y: touch.clientY });
                            }, LONG_PRESS_DELAY_MS);
                          }}
                          onTouchEnd={() => {
                            if (userLongPressTimerRef.current) {
                              clearTimeout(userLongPressTimerRef.current);
                              userLongPressTimerRef.current = null;
                            }
                          }}
                        >
                          <span>@{user.username || user.realName || 'user'}</span>
                          <span className="inline-flex items-center gap-1 text-[10px] font-mono uppercase opacity-80">
                            <span className={`h-2 w-2 rounded-full ${status.tone}`} />
                            {status.label}
                          </span>
                        </li>
                      );
                    })}
                  </ul>
                )}
              </div>
            </section>

            <section className={`rounded border p-2 ${activeTheme.panelGlass}`}>
              <h4 className="text-sm font-semibold">Shared Media / Links</h4>
              {sharedMediaSnippets.length === 0 ? (
                <p className="mt-2 text-xs opacity-80">No shared media yet.</p>
              ) : (
                <ul className="mt-2 space-y-1 text-xs">
                  {sharedMediaSnippets.map((message) => (
                    <li key={String(message._id)} className="rounded border px-2 py-1">
                      {(message.content || '').slice(0, 70)}
                    </li>
                  ))}
                </ul>
              )}
            </section>
            {activeConversation?.type === 'dm' ? (
              <section className={`rounded border p-2 ${activeTheme.panelGlass}`}>
                <h4 className="text-sm font-semibold">DM Security</h4>
                <label className="mt-2 flex items-center gap-2 text-xs">
                  <input
                    type="checkbox"
                    checked={rememberDmUnlock}
                    onChange={(event) => setRememberDmUnlock(event.target.checked)}
                    disabled={strictDmLockMode}
                  />
                  Remember unlock for 30 minutes (cookie cache)
                </label>
                <label className="mt-2 flex items-center gap-2 text-xs">
                  <input
                    type="checkbox"
                    checked={strictDmLockMode}
                    onChange={(event) => setStrictDmLockMode(event.target.checked)}
                  />
                  Strict mode (always lock, no cached access)
                </label>
                <button
                  type="button"
                  onClick={handleClearDmUnlockCache}
                  className={`mt-3 rounded border px-2 py-1 text-xs ${activeTheme.subtle}`}
                >
                  Reset cached DM access
                </button>
              </section>
            ) : null}
          </div>
        </aside>
      </div>
      {passwordModalOpen ? (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-3">
          <div className={`w-full max-w-sm rounded border p-3 ${activeTheme.panelGlass}`}>
            <h3 className="text-sm font-semibold">Unlock DM encryption</h3>
            <p className="mt-1 text-xs opacity-80">
              Enter your encryption password to unlock and decrypt now, or use offline mode to prepare messages for offline decryption.
            </p>
            <input
              type="password"
              value={passwordInput}
              onChange={(event) => setPasswordInput(event.target.value)}
              className={`mt-3 w-full rounded border px-2 py-1.5 text-sm ${activeTheme.input}`}
              placeholder="Encryption password"
              aria-label="Encryption password"
            />
            <div className="mt-3 flex justify-end gap-2">
              <button
                type="button"
                onClick={handlePasswordCancel}
                className={`rounded border px-2 py-1 text-xs ${activeTheme.subtle}`}
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleUseOfflineMode}
                className={`rounded border px-2 py-1 text-xs ${activeTheme.subtle}`}
              >
                Use Offline Mode
              </button>
              <button
                type="button"
                onClick={handlePasswordUnlock}
                className={`rounded border px-2 py-1 text-xs ${activeTheme.accent}`}
              >
                Unlock
              </button>
            </div>
          </div>
        </div>
      ) : null}
      {userContextMenu.open && userContextMenu.user ? (
        <div
          className={`fixed z-50 w-56 rounded border p-1 shadow-xl ${activeTheme.panelGlass}`}
          style={{ left: userContextMenu.x, top: userContextMenu.y }}
          role="menu"
          aria-label="User actions menu"
          onClick={(event) => event.stopPropagation()}
        >
          <button
            type="button"
            className="w-full rounded px-2 py-1 text-left text-sm hover:opacity-80"
            onClick={async () => {
              await handleStartDM(userContextMenu.user._id);
              closeUserContextMenu();
            }}
          >
            Send direct message
          </button>
          <button
            type="button"
            className="w-full rounded px-2 py-1 text-left text-sm hover:opacity-80"
            onClick={() => {
              handleViewUserSocial(userContextMenu.user);
              closeUserContextMenu();
            }}
          >
            View user social
          </button>
          <button
            type="button"
            className="w-full rounded px-2 py-1 text-left text-sm hover:opacity-80 disabled:opacity-50"
            disabled={String(userContextMenu.user._id) === String(profile?._id)}
            onClick={async () => {
              await handleRequestFriendship(userContextMenu.user);
              closeUserContextMenu();
            }}
          >
            Request friendship
          </button>
          <button
            type="button"
            className="w-full rounded px-2 py-1 text-left text-sm hover:opacity-80 disabled:opacity-50"
            disabled={String(userContextMenu.user._id) === String(profile?._id)}
            onClick={async () => {
              await handleBlockIgnore(userContextMenu.user);
              closeUserContextMenu();
            }}
          >
            Block/ignore
          </button>
        </div>
      ) : null}
    </div>
  );
}

export default Chat;
