const bcrypt = require('bcryptjs');
const User = require('../models/User');
const ONBOARDING_COMPLETE_STEP = 4;

const resolveAdminProfile = () => {
  const defaultProfile = {
    realName: 'Jared Hicks',
    country: 'US',
    zipCode: '78666'
  };

  const resolvedRealName = typeof process.env.UNIVERSAL_ADMIN_REAL_NAME === 'string'
    ? process.env.UNIVERSAL_ADMIN_REAL_NAME.trim()
    : '';
  const resolvedCountry = typeof process.env.UNIVERSAL_ADMIN_COUNTRY === 'string'
    ? process.env.UNIVERSAL_ADMIN_COUNTRY.trim().toUpperCase()
    : '';
  const resolvedZipCode = typeof process.env.UNIVERSAL_ADMIN_ZIP === 'string'
    ? process.env.UNIVERSAL_ADMIN_ZIP.trim()
    : '';

  return {
    realName: resolvedRealName || defaultProfile.realName,
    country: resolvedCountry || defaultProfile.country,
    zipCode: resolvedZipCode || defaultProfile.zipCode
  };
};

const ensureUniversalAdminAccount = async ({
  username,
  email,
  password,
  encryptionPassword,
  resetUsersOnInvalidOnboarding = false
} = {}) => {
  const adminProfile = resolveAdminProfile();
  const normalizedUsername = String(username || '').trim().toLowerCase();
  if (!normalizedUsername) {
    throw new Error('Universal admin username is required');
  }

  const resolvedEmail = typeof email === 'string' ? email.trim() : '';
  const resolvedPassword = typeof password === 'string' ? password : '';
  const resolvedEncryptionPassword = typeof encryptionPassword === 'string' ? encryptionPassword : '';

  if (!resolvedEmail) {
    throw new Error('Universal admin email is required');
  }
  if (!resolvedPassword) {
    throw new Error('Universal admin password is required');
  }

  let adminUser = await User.findOne({ username: normalizedUsername });
  const now = new Date();

  if (adminUser && adminUser.onboardingStatus !== 'completed' && resetUsersOnInvalidOnboarding) {
    const resetResult = await User.deleteMany({});
    adminUser = null;
    console.warn(`Universal ADMIN account onboarding state invalid. Reset ${resetResult?.deletedCount || 0} users and re-created ADMIN account.`);
  }

  if (!adminUser) {
    const passwordHash = await bcrypt.hash(resolvedPassword, 12);
    const encryptionPasswordHash = resolvedEncryptionPassword
      ? await bcrypt.hash(resolvedEncryptionPassword, 12)
      : null;

    adminUser = new User({
      realName: adminProfile.realName,
      username: normalizedUsername,
      email: resolvedEmail,
      passwordHash,
      country: adminProfile.country,
      zipCode: adminProfile.zipCode,
      registrationStatus: 'active',
      isAdmin: true,
      onboardingStatus: 'completed',
      onboardingStep: ONBOARDING_COMPLETE_STEP,
      mustResetPassword: false,
      encryptionPasswordHash,
      encryptionPasswordSetAt: encryptionPasswordHash ? now : null,
      encryptionPasswordVersion: encryptionPasswordHash ? 1 : 0
    });
    await adminUser.save();
    console.log('Universal ADMIN account created.');
    if (encryptionPasswordHash) {
      console.log('Universal ADMIN encryption password set.');
    }
    return { created: true, updated: false, encryptionPasswordUpdated: !!encryptionPasswordHash };
  }

  let updated = false;
  let privilegesRepaired = false;
  let encryptionPasswordUpdated = false;

  Object.entries(adminProfile).forEach(([key, value]) => {
    if (adminUser[key] !== value) {
      adminUser[key] = value;
      updated = true;
    }
  });

  if (!adminUser.isAdmin || adminUser.registrationStatus !== 'active') {
    adminUser.isAdmin = true;
    adminUser.registrationStatus = 'active';
    updated = true;
    privilegesRepaired = true;
  }

  if (adminUser.onboardingStatus !== 'completed' || adminUser.onboardingStep !== ONBOARDING_COMPLETE_STEP || adminUser.mustResetPassword) {
    adminUser.onboardingStatus = 'completed';
    adminUser.onboardingStep = ONBOARDING_COMPLETE_STEP;
    adminUser.mustResetPassword = false;
    updated = true;
  }

  if (!adminUser.encryptionPasswordHash && resolvedEncryptionPassword) {
    adminUser.encryptionPasswordHash = await bcrypt.hash(resolvedEncryptionPassword, 12);
    adminUser.encryptionPasswordSetAt = now;
    adminUser.encryptionPasswordVersion = 1;
    updated = true;
    encryptionPasswordUpdated = true;
  }

  if (updated) {
    adminUser.updatedAt = now;
    await adminUser.save();
  }

  if (privilegesRepaired) {
    console.log('Universal ADMIN account privileges repaired.');
  }
  if (encryptionPasswordUpdated) {
    console.log('Universal ADMIN encryption password set.');
  }

  return { created: false, updated, encryptionPasswordUpdated };
};

module.exports = { ensureUniversalAdminAccount };
