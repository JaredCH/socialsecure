const User = require('../models/User');
const NewsLocation = require('../models/NewsLocation');
const { canonicalizeNewsLocation } = require('../utils/newsLocationTaxonomy');

const normalizeToken = (value) => String(value || '').trim();

const buildCanonicalName = (canonical = {}) => {
  const parts = [
    canonical.city,
    canonical.stateCode || canonical.state,
    canonical.countryCode || canonical.country
  ].filter(Boolean);
  return parts.join(', ');
};

const buildLocationKey = (canonical = {}) => {
  if (canonical.cityKey) {
    return canonical.cityKey;
  }
  if (canonical.zipCode) {
    return `ZIP:${canonical.zipCode}`;
  }
  const stateToken = canonical.stateCode || normalizeToken(canonical.state).toUpperCase();
  const countryToken = canonical.countryCode || normalizeToken(canonical.country).toUpperCase();
  if (stateToken && countryToken) {
    return `STATE:${countryToken}:${stateToken}`;
  }
  // Country-only data is too broad for a valid master location key
  // Return null to indicate insufficient granularity
  return null;
};

const buildAliasSet = (canonical = {}, original = {}) => {
  const aliases = new Set();
  const maybeAdd = (value) => {
    const normalized = normalizeToken(value);
    if (normalized) aliases.add(normalized);
  };

  maybeAdd(original.city);
  maybeAdd(original.state);
  maybeAdd(original.country);
  maybeAdd(original.county);
  maybeAdd(original.zipCode);
  maybeAdd(canonical.city);
  maybeAdd(canonical.state);
  maybeAdd(canonical.stateCode);
  maybeAdd(canonical.country);
  maybeAdd(canonical.countryCode);
  maybeAdd(canonical.county);
  maybeAdd(canonical.zipCode);

  return [...aliases];
};

const canonicalizeLocationInput = (raw = {}) => {
  const canonical = canonicalizeNewsLocation({
    city: normalizeToken(raw.city),
    state: normalizeToken(raw.state),
    country: normalizeToken(raw.country || raw.countryCode),
    county: normalizeToken(raw.county),
    zipCode: normalizeToken(raw.zipCode)
  });

  const locationKey = buildLocationKey(canonical);
  if (!locationKey) {
    return null;
  }

  return {
    canonical,
    locationKey,
    canonicalName: buildCanonicalName(canonical),
    aliases: buildAliasSet(canonical, raw)
  };
};

const upsertMasterLocationFromUser = async ({ userId, location = {}, coordinates = null, queueOnDemand = false }) => {
  const normalized = canonicalizeLocationInput(location);
  if (!normalized) {
    return null;
  }

  const now = new Date();
  const pipeline = [
    {
      $set: {
        locationKey: normalized.locationKey,
        canonicalName: normalized.canonicalName,
        canonicalCity: normalized.canonical.city || null,
        canonicalState: normalized.canonical.state || null,
        canonicalStateCode: normalized.canonical.stateCode || null,
        canonicalCountry: normalized.canonical.country || null,
        canonicalCountryCode: normalized.canonical.countryCode || null,
        canonicalCounty: normalized.canonical.county || null,
        canonicalZipCode: normalized.canonical.zipCode || null,
        aliases: {
          $setUnion: [
            { $ifNull: ['$aliases', []] },
            normalized.aliases
          ]
        },
        isActive: true
      }
    }
  ];

  if (coordinates && Number.isFinite(Number(coordinates.lat)) && Number.isFinite(Number(coordinates.lon))) {
    pipeline.push({
      $set: {
        coordinates: {
          lat: Number(coordinates.lat),
          lon: Number(coordinates.lon)
        }
      }
    });
  }

  if (userId) {
    pipeline.push({
      $set: {
        userIds: {
          $setUnion: [
            { $ifNull: ['$userIds', []] },
            [userId]
          ]
        }
      }
    });
    pipeline.push({
      $set: {
        userCount: { $size: { $ifNull: ['$userIds', []] } }
      }
    });
  }

  if (queueOnDemand) {
    pipeline.push({
      $set: {
        onDemandRequestedAt: now,
        onDemandStatus: 'queued'
      }
    });
  }

  const updated = await NewsLocation.findOneAndUpdate(
    { locationKey: normalized.locationKey },
    pipeline,
    {
      new: true,
      upsert: true,
      setDefaultsOnInsert: true
    }
  );

  return updated;
};

const syncMasterLocationsFromUsers = async ({ limit = 2000 } = {}) => {
  const users = await User.find({
    registrationStatus: 'active',
    $or: [
      { city: { $exists: true, $ne: '' } },
      { state: { $exists: true, $ne: '' } },
      { zipCode: { $exists: true, $ne: '' } }
    ]
  })
    .select('_id city state country county zipCode location')
    .limit(limit)
    .lean();

  let touched = 0;
  for (const user of users) {
    const coordinates = Array.isArray(user.location?.coordinates)
      ? { lon: user.location.coordinates[0], lat: user.location.coordinates[1] }
      : null;
    const upserted = await upsertMasterLocationFromUser({
      userId: user._id,
      location: {
        city: user.city,
        state: user.state,
        country: user.country,
        county: user.county,
        zipCode: user.zipCode
      },
      coordinates,
      queueOnDemand: false
    });
    if (upserted) {
      touched += 1;
    }
  }

  return {
    usersScanned: users.length,
    locationsTouched: touched
  };
};

module.exports = {
  canonicalizeLocationInput,
  upsertMasterLocationFromUser,
  syncMasterLocationsFromUsers,
  buildLocationKey,
  buildCanonicalName,
  buildAliasSet
};
